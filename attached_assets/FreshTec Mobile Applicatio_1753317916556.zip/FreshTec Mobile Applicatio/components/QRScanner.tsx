import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Camera, 
  ArrowLeft, 
  CheckCircle, 
  Thermometer, 
  Droplets, 
  MapPin,
  Calendar,
  Leaf
} from 'lucide-react';
import type { Screen } from '../App';

interface QRScannerProps {
  onNavigate: (screen: Screen) => void;
}

export function QRScanner({ onNavigate }: QRScannerProps) {
  const [isScanning, setIsScanning] = useState(true);
  const [scannedData, setScannedData] = useState<any>(null);

  const mockScannedData = {
    productName: 'Tomates Cherry Orgânicos',
    batchId: 'TOM-2024-001',
    origin: 'Fazenda São João - Ibiúna/SP',
    harvestDate: '15/01/2024',
    currentTemp: '4°C',
    humidity: '85%',
    freshness: 'green',
    daysRemaining: 3,
    passportData: [
      { stage: 'Colheita', date: '15/01/2024', location: 'Fazenda São João', temp: '18°C' },
      { stage: 'Transporte', date: '16/01/2024', location: 'Rodovia BR-116', temp: '4°C' },
      { stage: 'Armazém', date: '17/01/2024', location: 'CEASA-SP', temp: '4°C' },
      { stage: 'Loja', date: '18/01/2024', location: 'Supermercado BH', temp: '4°C' }
    ]
  };

  const handleScan = () => {
    setIsScanning(false);
    // Simulate scanning delay
    setTimeout(() => {
      setScannedData(mockScannedData);
    }, 1500);
  };

  const getFreshnessColor = (freshness: string) => {
    switch (freshness) {
      case 'green': return 'text-green-600 bg-green-100';
      case 'yellow': return 'text-yellow-600 bg-yellow-100';
      case 'red': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getFreshnessText = (freshness: string) => {
    switch (freshness) {
      case 'green': return 'Muito Fresco';
      case 'yellow': return 'Consumir Logo';
      case 'red': return 'Consumir Hoje';
      default: return 'Status Desconhecido';
    }
  };

  if (scannedData) {
    return (
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('dashboard')}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl">Informações do Produto</h1>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">{scannedData.productName}</CardTitle>
              <Badge className={getFreshnessColor(scannedData.freshness)}>
                <CheckCircle className="w-3 h-3 mr-1" />
                {getFreshnessText(scannedData.freshness)}
              </Badge>
            </div>
            <p className="text-sm text-gray-600">Lote: {scannedData.batchId}</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-2 text-sm">
                <Thermometer className="w-4 h-4 text-blue-500" />
                <span>{scannedData.currentTemp}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Droplets className="w-4 h-4 text-blue-500" />
                <span>{scannedData.humidity}</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-gray-500" />
                <span>{scannedData.origin}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="w-4 h-4 text-gray-500" />
                <span>Colhido em {scannedData.harvestDate}</span>
              </div>
            </div>

            <div className="bg-green-50 p-3 rounded-lg text-center">
              <p className="text-2xl text-green-600 mb-1">{scannedData.daysRemaining}</p>
              <p className="text-sm text-green-700">dias de frescor restantes</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Leaf className="w-5 h-5 text-green-600" />
              Passaporte do Frescor
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {scannedData.passportData.map((stage: any, index: number) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <div className="flex-1">
                    <p className="text-sm">{stage.stage}</p>
                    <p className="text-xs text-gray-600">{stage.date} • {stage.location}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {stage.temp}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Button
          onClick={() => {
            setScannedData(null);
            setIsScanning(true);
          }}
          className="w-full bg-green-600 hover:bg-green-700"
        >
          Escanear Outro Produto
        </Button>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex items-center gap-3 p-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onNavigate('dashboard')}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h1 className="text-xl">Scanner QR Code</h1>
      </div>

      <div className="flex-1 relative bg-black">
        {isScanning ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative">
              <div className="w-64 h-64 border-2 border-white opacity-50 rounded-lg" />
              <div className="absolute inset-0 border-4 border-green-500 rounded-lg animate-pulse" />
            </div>
          </div>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-white text-center">
              <div className="animate-spin w-8 h-8 border-2 border-white border-t-transparent rounded-full mx-auto mb-4" />
              <p>Processando código...</p>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-white space-y-4">
        <div className="text-center">
          <p className="text-gray-600 mb-2">
            Aponte para o QR code do Selo de Frescor Digital
          </p>
          <p className="text-sm text-gray-500">
            Mantenha o código centralizado na tela
          </p>
        </div>

        {isScanning && (
          <Button
            onClick={handleScan}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            <Camera className="w-4 h-4 mr-2" />
            Simular Escaneamento
          </Button>
        )}
      </div>
    </div>
  );
}