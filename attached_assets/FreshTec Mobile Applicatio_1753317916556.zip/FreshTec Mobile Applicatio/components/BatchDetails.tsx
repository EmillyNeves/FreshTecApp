import React from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  ArrowLeft, 
  Thermometer, 
  Droplets, 
  MapPin, 
  Calendar,
  Truck,
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  Package,
  Brain,
  TreePine,
  FileText,
  Download,
  Shield,
  Lightbulb,
  Users,
  Zap
} from 'lucide-react';
import type { UserType, Screen } from '../App';

interface BatchDetailsProps {
  batchId: string;
  userType: UserType;
  onNavigate: (screen: Screen) => void;
}

export function BatchDetails({ batchId, userType, onNavigate }: BatchDetailsProps) {
  const mockBatchData = {
    id: batchId,
    name: 'Tomates Cherry Orgânicos',
    status: 'green',
    currentTemp: 4.2,
    targetTemp: 4.0,
    humidity: 85,
    location: 'Transporte - BR-116 km 245',
    origin: 'Fazenda São João - Ibiúna/SP',
    destination: 'Supermercado ABC - Belo Horizonte/MG',
    harvestDate: '15/01/2024',
    estimatedArrival: '19/01/2024',
    weight: '500 kg',
    quality: 98,
    // Predictive Analytics
    spoilageRisk: 15, // percentage
    spoilagePrediction: '7 dias restantes',
    aiRecommendations: [
      'Manter temperatura entre 3-5°C',
      'Distribuir preferencialmente em 48h',
      'Considerar rota alternativa por Campinas'
    ],
    // Carbon Footprint
    carbonFootprint: {
      transport: 12.5,
      refrigeration: 8.2,
      packaging: 3.1,
      total: 23.8
    },
    carbonComparison: -15, // % compared to average
    // Blockchain Data
    blockchainHash: '0x1a2b3c4d5e6f7g8h9i0j',
    verificationStatus: 'verified',
    immutableRecords: 24,
    // Storage Tips (for consumers)
    storageRecommendations: [
      'Armazene em temperatura entre 0-4°C',
      'Mantenha longe da luz solar direta',
      'Não lave antes de armazenar',
      'Consuma em até 5 dias para máximo frescor'
    ],
    environmentalImpact: {
      waterSaved: 45, // liters
      co2Prevented: 2.3, // kg
      wasteReduced: 0.8 // kg
    },
    temperatureHistory: [
      { time: '00:00', temp: 4.1 },
      { time: '04:00', temp: 4.2 },
      { time: '08:00', temp: 4.0 },
      { time: '12:00', temp: 4.3 },
      { time: '16:00', temp: 4.1 },
      { time: '20:00', temp: 4.2 },
    ],
    timeline: [
      { stage: 'Colheita', date: '15/01/2024 08:00', location: 'Fazenda São João', status: 'completed', hash: '0x1a2b3c' },
      { stage: 'Embalagem', date: '15/01/2024 14:00', location: 'Centro de Distribuição', status: 'completed', hash: '0x4d5e6f' },
      { stage: 'Transporte', date: '16/01/2024 06:00', location: 'Rodovia BR-116', status: 'current', hash: '0x7g8h9i' },
      { stage: 'Entrega', date: '19/01/2024 10:00', location: 'Supermercado ABC', status: 'pending', hash: null },
    ]
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'green': return 'text-green-600 bg-green-100';
      case 'yellow': return 'text-yellow-600 bg-yellow-100';
      case 'red': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStageIcon = (stage: string) => {
    switch (stage) {
      case 'Colheita': return Calendar;
      case 'Embalagem': return Package;
      case 'Transporte': return Truck;
      case 'Entrega': return MapPin;
      default: return Package;
    }
  };

  const getStageStatus = (status: string) => {
    switch (status) {
      case 'completed': return { color: 'bg-green-500', text: 'Concluído' };
      case 'current': return { color: 'bg-blue-500', text: 'Em andamento' };
      case 'pending': return { color: 'bg-gray-300', text: 'Pendente' };
      default: return { color: 'bg-gray-300', text: 'Desconhecido' };
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onNavigate('dashboard')}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-xl">{mockBatchData.name}</h1>
          <p className="text-sm text-gray-600">Lote #{mockBatchData.id}</p>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="ai">IA</TabsTrigger>
          <TabsTrigger value="environment">Ambiente</TabsTrigger>
          <TabsTrigger value="blockchain">Blockchain</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Status Card */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Status Atual</CardTitle>
                <Badge className={getStatusColor(mockBatchData.status)}>
                  Condições Ideais
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Thermometer className="w-4 h-4 text-blue-500" />
                    <span className="text-sm text-gray-600">Temperatura</span>
                  </div>
                  <p className="text-2xl">{mockBatchData.currentTemp}°C</p>
                  <p className="text-xs text-gray-500">Meta: {mockBatchData.targetTemp}°C</p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Droplets className="w-4 h-4 text-blue-500" />
                    <span className="text-sm text-gray-600">Umidade</span>
                  </div>
                  <p className="text-2xl">{mockBatchData.humidity}%</p>
                  <p className="text-xs text-gray-500">Faixa ideal</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-600">Localização Atual</span>
                </div>
                <p className="text-sm">{mockBatchData.location}</p>
              </div>
            </CardContent>
          </Card>

          {/* Temperature Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Temperatura (últimas 24h)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-24 flex items-end justify-between gap-2">
                {mockBatchData.temperatureHistory.map((point, index) => (
                  <div key={index} className="flex flex-col items-center flex-1">
                    <div 
                      className="bg-blue-500 w-full rounded-t"
                      style={{ height: `${(point.temp / 5) * 100}%` }}
                    />
                    <p className="text-xs text-gray-600 mt-1">{point.time}</p>
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-2">
                <span>0°C</span>
                <span>5°C</span>
              </div>
            </CardContent>
          </Card>

          {/* Consumer Storage Tips */}
          {userType === 'consumer' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-yellow-600" />
                  Dicas de Armazenamento
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {mockBatchData.storageRecommendations.map((tip, index) => (
                    <div key={index} className="flex items-start gap-2 p-2 bg-yellow-50 rounded">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2" />
                      <p className="text-sm text-yellow-800">{tip}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="ai" className="space-y-4">
          {/* Predictive Analytics */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-600" />
                Análise Preditiva
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Risco de Deterioração</span>
                  <span>{mockBatchData.spoilageRisk}%</span>
                </div>
                <Progress value={mockBatchData.spoilageRisk} className="h-2" />
                <p className="text-sm text-gray-600">{mockBatchData.spoilagePrediction}</p>
              </div>

              <div className="space-y-3">
                <h4 className="text-sm text-gray-900">Recomendações da IA:</h4>
                {mockBatchData.aiRecommendations.map((recommendation, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-purple-50 rounded-lg">
                    <Brain className="w-4 h-4 text-purple-600 mt-0.5" />
                    <p className="text-sm text-purple-800">{recommendation}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quality Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Métricas de Qualidade</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-2xl text-green-600">{mockBatchData.quality}%</p>
                  <p className="text-xs text-gray-600">Qualidade</p>
                </div>
                <div>
                  <p className="text-2xl text-blue-600">{mockBatchData.weight}</p>
                  <p className="text-xs text-gray-600">Peso</p>
                </div>
                <div>
                  <p className="text-2xl text-purple-600">94%</p>
                  <p className="text-xs text-gray-600">Precisão IA</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="environment" className="space-y-4">
          {/* Carbon Footprint */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TreePine className="w-5 h-5 text-green-600" />
                Pegada de Carbono
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-3xl text-green-600">{mockBatchData.carbonFootprint.total} kg</p>
                <p className="text-sm text-gray-600">CO₂ equivalente</p>
                <Badge className={mockBatchData.carbonComparison < 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                  {mockBatchData.carbonComparison > 0 ? '+' : ''}{mockBatchData.carbonComparison}% vs média
                </Badge>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Transporte</span>
                  <span className="text-sm">{mockBatchData.carbonFootprint.transport} kg CO₂</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Refrigeração</span>
                  <span className="text-sm">{mockBatchData.carbonFootprint.refrigeration} kg CO₂</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Embalagem</span>
                  <span className="text-sm">{mockBatchData.carbonFootprint.packaging} kg CO₂</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Environmental Impact (Consumer) */}
          {userType === 'consumer' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-green-600" />
                  Seu Impacto Positivo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-xl text-blue-600">{mockBatchData.environmentalImpact.waterSaved}L</p>
                    <p className="text-xs text-gray-600">água poupada</p>
                  </div>
                  <div>
                    <p className="text-xl text-green-600">{mockBatchData.environmentalImpact.co2Prevented} kg</p>
                    <p className="text-xs text-gray-600">CO₂ evitado</p>
                  </div>
                  <div>
                    <p className="text-xl text-purple-600">{mockBatchData.environmentalImpact.wasteReduced} kg</p>
                    <p className="text-xs text-gray-600">desperdício evitado</p>
                  </div>
                </div>

                <Button
                  onClick={() => onNavigate('community')}
                  className="w-full mt-4 bg-green-600 hover:bg-green-700"
                >
                  <Users className="w-4 h-4 mr-2" />
                  Doar Este Item
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Compliance (B2B) */}
          {userType !== 'consumer' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  Conformidade Regulatória
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm">ANVISA RDC 216/2004</span>
                  <Badge className="bg-green-100 text-green-800">Conforme</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Cadeia do Frio</span>
                  <Badge className="bg-green-100 text-green-800">Mantida</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Rastreabilidade</span>
                  <Badge className="bg-green-100 text-green-800">100%</Badge>
                </div>

                <Button variant="outline" className="w-full">
                  <Download className="w-4 h-4 mr-2" />
                  Baixar Relatório de Conformidade
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="blockchain" className="space-y-4">
          {/* Blockchain Verification */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-blue-600" />
                Verificação Blockchain
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">Status</span>
                <Badge className="bg-green-100 text-green-800">
                  <Shield className="w-3 h-3 mr-1" />
                  Verificado
                </Badge>
              </div>
              
              <div className="space-y-2">
                <p className="text-sm text-gray-600">Hash do Lote:</p>
                <div className="bg-gray-100 p-2 rounded text-xs font-mono break-all">
                  {mockBatchData.blockchainHash}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <p className="text-xl text-blue-600">{mockBatchData.immutableRecords}</p>
                  <p className="text-xs text-gray-600">registros imutáveis</p>
                </div>
                <div>
                  <p className="text-xl text-green-600">100%</p>
                  <p className="text-xs text-gray-600">integridade</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Blockchain Timeline */}
          <Card>
            <CardHeader>
              <CardTitle>Passaporte do Frescor (Blockchain)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockBatchData.timeline.map((stage, index) => {
                  const Icon = getStageIcon(stage.stage);
                  const stageStatus = getStageStatus(stage.status);
                  
                  return (
                    <div key={index} className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${stageStatus.color}`} />
                      <Icon className="w-4 h-4 text-gray-600" />
                      <div className="flex-1">
                        <p className="text-sm">{stage.stage}</p>
                        <p className="text-xs text-gray-600">{stage.date}</p>
                        <p className="text-xs text-gray-500">{stage.location}</p>
                        {stage.hash && (
                          <p className="text-xs font-mono text-blue-600">{stage.hash}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {stageStatus.text}
                        </Badge>
                        {stage.hash && (
                          <Zap className="w-3 h-3 text-blue-500" />
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}