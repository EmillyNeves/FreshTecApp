import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Switch } from './ui/switch';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { 
  ArrowLeft, 
  User, 
  Bell, 
  Smartphone, 
  Shield, 
  HelpCircle, 
  LogOut,
  Moon,
  Globe,
  Wifi,
  Download
} from 'lucide-react';
import type { Screen } from '../App';

interface SettingsScreenProps {
  onLogout: () => void;
  onNavigate: (screen: Screen) => void;
}

export function SettingsScreen({ onLogout, onNavigate }: SettingsScreenProps) {
  const [notifications, setNotifications] = useState({
    freshness: true,
    temperature: true,
    delivery: false,
    marketing: false
  });
  
  const [offlineMode, setOfflineMode] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [autoSync, setAutoSync] = useState(true);

  const handleNotificationChange = (key: string, value: boolean) => {
    setNotifications(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onNavigate('dashboard')}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h1 className="text-xl">Configurações</h1>
      </div>

      {/* Profile Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Perfil
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <User className="w-8 h-8 text-green-600" />
            </div>
            <div className="flex-1">
              <p className="text-lg">João Silva</p>
              <p className="text-sm text-gray-600">joao.silva@email.com</p>
              <p className="text-xs text-gray-500">Consumidor Premium</p>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-3">
            <div>
              <Label htmlFor="name">Nome</Label>
              <Input id="name" defaultValue="João Silva" className="mt-1" />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" defaultValue="joao.silva@email.com" className="mt-1" />
            </div>
          </div>
          
          <Button variant="outline" className="w-full">
            Atualizar Perfil
          </Button>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notificações
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">Alertas de Frescor</p>
              <p className="text-xs text-gray-600">Quando alimentos estão próximos do vencimento</p>
            </div>
            <Switch
              checked={notifications.freshness}
              onCheckedChange={(value) => handleNotificationChange('freshness', value)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">Alertas de Temperatura</p>
              <p className="text-xs text-gray-600">Mudanças críticas de temperatura</p>
            </div>
            <Switch
              checked={notifications.temperature}
              onCheckedChange={(value) => handleNotificationChange('temperature', value)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">Atualizações de Entrega</p>
              <p className="text-xs text-gray-600">Status de transporte e entrega</p>
            </div>
            <Switch
              checked={notifications.delivery}
              onCheckedChange={(value) => handleNotificationChange('delivery', value)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">Ofertas e Novidades</p>
              <p className="text-xs text-gray-600">Promoções e atualizações do app</p>
            </div>
            <Switch
              checked={notifications.marketing}
              onCheckedChange={(value) => handleNotificationChange('marketing', value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* App Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Configurações do App
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">Modo Escuro</p>
              <p className="text-xs text-gray-600">Interface com cores escuras</p>
            </div>
            <Switch
              checked={darkMode}
              onCheckedChange={setDarkMode}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">Modo Offline</p>
              <p className="text-xs text-gray-600">Funcionar sem conexão com internet</p>
            </div>
            <Switch
              checked={offlineMode}
              onCheckedChange={setOfflineMode}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">Sincronização Automática</p>
              <p className="text-xs text-gray-600">Sync dados quando conectado</p>
            </div>
            <Switch
              checked={autoSync}
              onCheckedChange={setAutoSync}
            />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-gray-600" />
              <span className="text-sm">Idioma</span>
            </div>
            <Button variant="outline" size="sm">
              Português (BR)
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Data & Privacy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Dados e Privacidade
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" className="w-full justify-start">
            <Download className="w-4 h-4 mr-2" />
            Exportar Meus Dados
          </Button>
          
          <Button variant="outline" className="w-full justify-start">
            <Wifi className="w-4 h-4 mr-2" />
            Gerenciar Dados Offline
          </Button>
          
          <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700">
            <Shield className="w-4 h-4 mr-2" />
            Limpar Todos os Dados
          </Button>
        </CardContent>
      </Card>

      {/* Help & Support */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5" />
            Ajuda e Suporte
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button variant="outline" className="w-full justify-start">
            Central de Ajuda
          </Button>
          
          <Button variant="outline" className="w-full justify-start">
            Entrar em Contato
          </Button>
          
          <Button variant="outline" className="w-full justify-start">
            Reportar Problema
          </Button>
          
          <div className="pt-3 border-t">
            <p className="text-xs text-gray-500 text-center">
              FreshTec v1.0.0
            </p>
            <p className="text-xs text-gray-500 text-center">
              Desenvolvido com ♥ para reduzir desperdício
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Logout */}
      <Card className="border-red-200">
        <CardContent className="p-4">
          <Button 
            onClick={onLogout}
            variant="destructive" 
            className="w-full"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sair da Conta
          </Button>
        </CardContent>
      </Card>

      {/* Bottom spacing for navigation */}
      <div className="h-20" />
    </div>
  );
}