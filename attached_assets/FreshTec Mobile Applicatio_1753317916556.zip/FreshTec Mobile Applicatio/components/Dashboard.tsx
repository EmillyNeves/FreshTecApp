import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { 
  Thermometer, 
  Droplets, 
  MapPin, 
  AlertTriangle, 
  Package, 
  Clock,
  Leaf,
  QrCode,
  TrendingUp,
  CheckCircle,
  Brain,
  Zap,
  FileText,
  TreePine,
  Users,
  Lightbulb
} from 'lucide-react';
import type { UserType, Screen } from '../App';

interface DashboardProps {
  userType: UserType;
  onBatchSelect: (batchId: string) => void;
  onNavigate: (screen: Screen) => void;
}

export function Dashboard({ userType, onBatchSelect, onNavigate }: DashboardProps) {
  const getCurrentGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  const mockBatches = [
    {
      id: '001',
      name: 'Tomates Cherry',
      temperature: '4°C',
      humidity: '85%',
      status: 'green',
      location: 'Transporte - SP',
      timeRemaining: '2 dias',
      spoilageRisk: 'low',
      carbonFootprint: 2.3,
      aiPrediction: 'Condições ideais mantidas'
    },
    {
      id: '002',
      name: 'Alface Americana',
      temperature: '6°C',
      humidity: '90%',
      status: 'yellow',
      location: 'Armazém - RJ',
      timeRemaining: '1 dia',
      spoilageRisk: 'medium',
      carbonFootprint: 1.8,
      aiPrediction: 'Recomenda-se distribuição em 12h'
    },
    {
      id: '003',
      name: 'Bananas Nanica',
      temperature: '8°C',
      humidity: '75%',
      status: 'red',
      location: 'Loja - BH',
      timeRemaining: '12 horas',
      spoilageRisk: 'high',
      carbonFootprint: 3.1,
      aiPrediction: 'Ação imediata necessária'
    }
  ];

  const mockConsumerItems = [
    {
      id: '001',
      name: 'Tomates',
      freshness: 'green',
      daysLeft: 3,
      origin: 'Fazenda São João',
      storageOptimal: true,
      co2Impact: 0.8,
      storagetip: 'Mantenha em temperatura ambiente'
    },
    {
      id: '002',
      name: 'Alface',
      freshness: 'yellow',
      daysLeft: 1,
      origin: 'Horta Orgânica',
      storageOptimal: false,
      co2Impact: 0.5,
      storagetip: 'Mova para geladeira para prolongar vida útil'
    },
    {
      id: '003',
      name: 'Bananas',
      freshness: 'red',
      daysLeft: 0,
      origin: 'Sítio Boa Vista',
      storageOptimal: true,
      co2Impact: 1.2,
      storageTip: 'Ideais para vitaminas ou doação'
    }
  ];

  const mockEnvironmentalData = {
    monthlyWasteReduction: 15.7, // kg
    co2Saved: 23.4, // kg
    waterSaved: 156, // litros
    treesEquivalent: 0.8,
    weeklyProgress: 78 // percentage
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'green': return 'bg-green-500';
      case 'yellow': return 'bg-yellow-500';
      case 'red': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'green': return 'Ótimo';
      case 'yellow': return 'Atenção';
      case 'red': return 'Crítico';
      default: return 'Desconhecido';
    }
  };

  const getSpoilageRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getSpoilageRiskText = (risk: string) => {
    switch (risk) {
      case 'low': return 'Baixo Risco';
      case 'medium': return 'Risco Médio';
      case 'high': return 'Alto Risco';
      default: return 'Analisando';
    }
  };

  if (userType === 'consumer') {
    return (
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl text-gray-900">{getCurrentGreeting()}</h1>
            <p className="text-gray-600">Seus alimentos frescos</p>
          </div>
          <Button
            onClick={() => onNavigate('scanner')}
            className="bg-green-600 hover:bg-green-700"
            size="sm"
          >
            <QrCode className="w-4 h-4 mr-2" />
            Escanear
          </Button>
        </div>

        {/* Environmental Impact */}
        <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TreePine className="w-5 h-5 text-green-600" />
              Seu Impacto Ambiental
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="text-center">
                <p className="text-2xl text-green-600">{mockEnvironmentalData.monthlyWasteReduction} kg</p>
                <p className="text-xs text-gray-600">desperdício evitado</p>
              </div>
              <div className="text-center">
                <p className="text-2xl text-blue-600">{mockEnvironmentalData.co2Saved} kg</p>
                <p className="text-xs text-gray-600">CO₂ poupados</p>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Meta semanal</span>
                <span>{mockEnvironmentalData.weeklyProgress}%</span>
              </div>
              <Progress value={mockEnvironmentalData.weeklyProgress} className="h-2" />
            </div>
            
            <Badge className="mt-3 bg-green-100 text-green-800">
              <TreePine className="w-3 h-3 mr-1" />
              Equivale a {mockEnvironmentalData.treesEquivalent} árvore plantada
            </Badge>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-3">
          <Button
            onClick={() => onNavigate('community')}
            variant="outline"
            className="h-20 flex-col space-y-1"
          >
            <Users className="w-6 h-6 text-green-600" />
            <span className="text-sm">Doar Alimentos</span>
          </Button>
          <Button
            onClick={() => onNavigate('analytics')}
            variant="outline"
            className="h-20 flex-col space-y-1"
          >
            <Leaf className="w-6 h-6 text-blue-600" />
            <span className="text-sm">Meu Impacto</span>
          </Button>
        </div>

        <div>
          <h3 className="mb-3">Meus Alimentos</h3>
          <div className="space-y-3">
            {mockConsumerItems.map((item) => (
              <Card key={item.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onBatchSelect(item.id)}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(item.freshness)}`} />
                      <div>
                        <p className="text-gray-900">{item.name}</p>
                        <p className="text-xs text-gray-500">{item.origin}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm">{item.daysLeft > 0 ? `${item.daysLeft} dias` : 'Hoje'}</p>
                      <p className="text-xs text-gray-500">restantes</p>
                    </div>
                  </div>

                  {!item.storageOptimal && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mb-2">
                      <div className="flex items-start gap-2">
                        <Lightbulb className="w-4 h-4 text-yellow-600 mt-0.5" />
                        <p className="text-xs text-yellow-800">{item.storageTip}</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Impacto: {item.co2Impact} kg CO₂</span>
                    {item.daysLeft === 0 && (
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          onNavigate('community');
                        }}
                        size="sm"
                        variant="outline"
                        className="text-xs h-6"
                      >
                        <Users className="w-3 h-3 mr-1" />
                        Doar
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {mockConsumerItems.some(item => item.freshness === 'red') && (
          <Alert className="border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              Você tem alimentos próximos do vencimento. Considere consumi-los ou doá-los!
            </AlertDescription>
          </Alert>
        )}
      </div>
    );
  }

  // B2B Dashboard with Advanced Features
  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl text-gray-900">{getCurrentGreeting()}</h1>
          <p className="text-gray-600">
            {userType === 'producer' && 'Painel do Produtor'}
            {userType === 'transporter' && 'Painel do Transportador'}
            {userType === 'retailer' && 'Painel do Varejista'}
          </p>
        </div>
        <Button
          onClick={() => onNavigate('analytics')}
          variant="outline"
          size="sm"
        >
          <TrendingUp className="w-4 h-4 mr-2" />
          Análises
        </Button>
      </div>

      {/* Advanced Metrics */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Brain className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <p className="text-2xl text-gray-900">94%</p>
            <p className="text-xs text-gray-600">precisão IA</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <TreePine className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <p className="text-2xl text-gray-900">156 kg</p>
            <p className="text-xs text-gray-600">CO₂ poupados</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-3 gap-2">
        <Button variant="outline" size="sm" className="flex-col h-16 space-y-1">
          <FileText className="w-4 h-4" />
          <span className="text-xs">Relatórios</span>
        </Button>
        <Button variant="outline" size="sm" className="flex-col h-16 space-y-1">
          <Zap className="w-4 h-4" />
          <span className="text-xs">Blockchain</span>
        </Button>
        <Button variant="outline" size="sm" className="flex-col h-16 space-y-1">
          <TreePine className="w-4 h-4" />
          <span className="text-xs">Carbono</span>
        </Button>
      </div>

      {/* AI Alerts */}
      {mockBatches.some(batch => batch.spoilageRisk === 'high') && (
        <Alert className="border-red-200 bg-red-50">
          <Brain className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            IA detectou alto risco de deterioração em 1 lote. Ação recomendada: redirecionar para mercados próximos.
          </AlertDescription>
        </Alert>
      )}

      <div>
        <h3 className="mb-3">Lotes Monitorados</h3>
        <div className="space-y-3">
          {mockBatches.map((batch) => (
            <Card key={batch.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => onBatchSelect(batch.id)}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${getStatusColor(batch.status)}`} />
                    <div>
                      <p className="text-gray-900">{batch.name}</p>
                      <p className="text-xs text-gray-500">Lote #{batch.id}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant={batch.status === 'green' ? 'default' : batch.status === 'yellow' ? 'secondary' : 'destructive'}>
                      {getStatusText(batch.status)}
                    </Badge>
                    <Badge className={getSpoilageRiskColor(batch.spoilageRisk)}>
                      <Brain className="w-3 h-3 mr-1" />
                      {getSpoilageRiskText(batch.spoilageRisk)}
                    </Badge>
                  </div>
                </div>
                
                <div className="grid grid-cols-4 gap-3 text-sm mb-2">
                  <div className="flex items-center gap-1">
                    <Thermometer className="w-3 h-3 text-blue-500" />
                    <span>{batch.temperature}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Droplets className="w-3 h-3 text-blue-500" />
                    <span>{batch.humidity}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-gray-500" />
                    <span>{batch.timeRemaining}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <TreePine className="w-3 h-3 text-green-500" />
                    <span>{batch.carbonFootprint} kg</span>
                  </div>
                </div>

                <div className="bg-purple-50 border border-purple-200 rounded p-2 mb-2">
                  <div className="flex items-start gap-2">
                    <Brain className="w-3 h-3 text-purple-600 mt-0.5" />
                    <p className="text-xs text-purple-800">{batch.aiPrediction}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-3 h-3" />
                  <span>{batch.location}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}