import React from 'react';
import { Button } from './ui/button';
import { 
  Home, 
  QrCode, 
  BarChart3, 
  Package, 
  Settings,
  Users
} from 'lucide-react';
import type { UserType, Screen } from '../App';

interface NavigationProps {
  currentScreen: Screen;
  onNavigate: (screen: Screen) => void;
  userType: UserType;
}

export function Navigation({ currentScreen, onNavigate, userType }: NavigationProps) {
  const getNavigationItems = () => {
    const baseItems = [
      { screen: 'dashboard' as Screen, icon: Home, label: 'Início' },
      { screen: 'scanner' as Screen, icon: QrCode, label: 'Scanner' },
    ];

    if (userType === 'consumer') {
      return [
        ...baseItems,
        { screen: 'community' as Screen, icon: Users, label: 'Comunidade' },
        { screen: 'analytics' as Screen, icon: BarChart3, label: 'Impacto' },
        { screen: 'settings' as Screen, icon: Settings, label: 'Config' },
      ];
    } else {
      return [
        ...baseItems,
        { screen: 'analytics' as Screen, icon: BarChart3, label: 'Análises' },
        { screen: 'settings' as Screen, icon: Settings, label: 'Config' },
      ];
    }
  };

  const navigationItems = getNavigationItems();

  return (
    <div className="bg-white border-t border-gray-200 px-4 py-2 safe-area-pb">
      <div className="flex justify-around">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.screen;
          
          return (
            <Button
              key={item.screen}
              variant="ghost"
              size="sm"
              onClick={() => onNavigate(item.screen)}
              className={`flex flex-col items-center gap-1 px-3 py-2 h-auto ${
                isActive 
                  ? 'text-green-600 bg-green-50' 
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
}