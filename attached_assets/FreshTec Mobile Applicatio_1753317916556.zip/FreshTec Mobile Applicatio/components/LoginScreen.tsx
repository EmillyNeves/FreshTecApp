import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Leaf, Truck, Store, User } from 'lucide-react';
import type { UserType } from '../App';

interface LoginScreenProps {
  onLogin: (userType: UserType) => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [userType, setUserType] = useState<UserType>('consumer');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate authentication
    setTimeout(() => {
      onLogin(userType);
      setIsLoading(false);
    }, 1000);
  };

  const userTypeOptions = [
    { value: 'producer', label: 'Produtor', icon: Leaf, description: 'Fazendas e produtores rurais' },
    { value: 'transporter', label: 'Transportador', icon: Truck, description: 'Logística e transporte' },
    { value: 'retailer', label: 'Varejista', icon: Store, description: 'Supermercados e lojas' },
    { value: 'consumer', label: 'Consumidor', icon: User, description: 'Consumidor final' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto mb-4 w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
            <Leaf className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl text-green-700">FreshTec</CardTitle>
          <CardDescription className="text-gray-600">
            Passaporte do Frescor Digital
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="mt-1"
                />
              </div>
              
              <div>
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="mt-1"
                />
              </div>
            </div>

            <div>
              <Label className="text-base mb-3 block">Tipo de usuário</Label>
              <RadioGroup
                value={userType}
                onValueChange={(value) => setUserType(value as UserType)}
                className="space-y-3"
              >
                {userTypeOptions.map((option) => {
                  const Icon = option.icon;
                  return (
                    <div key={option.value} className="flex items-center space-x-3 p-3 rounded-lg border hover:bg-gray-50 transition-colors">
                      <RadioGroupItem value={option.value} id={option.value} />
                      <div className="flex items-center space-x-3 flex-1">
                        <Icon className="w-5 h-5 text-green-600" />
                        <div>
                          <Label htmlFor={option.value} className="cursor-pointer">
                            {option.label}
                          </Label>
                          <p className="text-xs text-gray-500">{option.description}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </RadioGroup>
            </div>

            <Button
              type="submit"
              className="w-full bg-green-600 hover:bg-green-700"
              disabled={isLoading}
            >
              {isLoading ? 'Entrando...' : 'Entrar'}
            </Button>

            <div className="text-center">
              <Button variant="ghost" type="button" className="text-sm">
                Esqueceu a senha?
              </Button>
            </div>
          </form>

          <div className="mt-6 pt-6 border-t">
            <Button
              variant="outline"
              className="w-full"
              onClick={() => onLogin('consumer')}
            >
              Entrar como convidado
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}