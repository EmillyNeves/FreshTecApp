import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  ArrowLeft, 
  TrendingUp, 
  TrendingDown, 
  Leaf, 
  Package, 
  Thermometer,
  Award,
  Target,
  Calendar,
  TreePine,
  Droplets,
  Zap,
  Brain,
  FileText,
  Users,
  Heart
} from 'lucide-react';
import type { UserType, Screen } from '../App';

interface AnalyticsScreenProps {
  userType: UserType;
  onNavigate: (screen: Screen) => void;
}

export function AnalyticsScreen({ userType, onNavigate }: AnalyticsScreenProps) {
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  const mockConsumerData = {
    wasteReduced: 12.3,
    wasteReductionTrend: 15,
    moneySaved: 85.60,
    co2Saved: 23.7,
    waterSaved: 234,
    treesEquivalent: 1.2,
    freshnessDays: 6.8,
    donationCount: 8,
    familiesHelped: 3,
    sustainabilityScore: 87,
    monthlyProgress: [
      { month: 'Jan', waste: 2.1, co2: 5.2, water: 45 },
      { month: 'Fev', waste: 1.8, co2: 4.8, water: 52 },
      { month: 'Mar', waste: 1.2, co2: 6.1, water: 67 },
      { month: 'Abr', waste: 0.9, co2: 7.6, water: 70 },
    ],
    achievements: [
      { title: 'Eco Guardian', description: '30 dias sem desperdiçar', icon: '🌱', date: '2024-01-15' },
      { title: 'Doador Generoso', description: '10 doações realizadas', icon: '❤️', date: '2024-01-10' },
      { title: 'Carbon Hero', description: '50kg de CO₂ poupados', icon: '🌍', date: '2024-01-05' },
      { title: 'Water Saver', description: '500L de água preservados', icon: '💧', date: '2023-12-28' },
    ],
    weeklyGoals: {
      wasteReduction: { target: 2.0, current: 1.7, unit: 'kg' },
      co2Savings: { target: 8.0, current: 6.2, unit: 'kg' },
      donations: { target: 3, current: 2, unit: 'itens' }
    }
  };

  const mockB2BData = {
    totalBatches: 156,
    qualityScore: 94.2,
    lossPercentage: 2.8,
    lossReduction: -12,
    avgTemperature: 4.1,
    deliveryOnTime: 98.5,
    aiAccuracy: 96.7,
    carbonFootprint: 1247.5,
    carbonReduction: -18,
    complianceScore: 99.2,
    blockchainRecords: 1842,
    predictiveAlerts: 23,
    monthlyLosses: [
      { month: 'Jan', loss: 3.2, carbon: 1350, ai: 94 },
      { month: 'Fev', loss: 2.9, carbon: 1290, ai: 95 },
      { month: 'Mar', loss: 2.6, carbon: 1220, ai: 96 },
      { month: 'Abr', loss: 2.8, carbon: 1247, ai: 97 },
    ],
    alerts: [
      { type: 'critical', count: 2, description: 'Temperaturas críticas' },
      { type: 'warning', count: 8, description: 'Atrasos na entrega' },
      { type: 'info', count: 15, description: 'Manutenções programadas' },
    ],
    sustainabilityMetrics: {
      energyEfficiency: 89,
      wasteReduction: 76,
      carbonNeutral: 45,
      circularEconomy: 62
    }
  };

  const ConsumerAnalytics = () => (
    <div className="space-y-6">
      <Tabs defaultValue="impact" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="impact">Impacto</TabsTrigger>
          <TabsTrigger value="goals">Metas</TabsTrigger>
          <TabsTrigger value="community">Comunidade</TabsTrigger>
        </TabsList>

        <TabsContent value="impact" className="space-y-4">
          {/* Sustainability Score */}
          <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TreePine className="w-5 h-5 text-green-600" />
                Pontuação de Sustentabilidade
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-3">
                <p className="text-4xl text-green-600">{mockConsumerData.sustainabilityScore}</p>
                <p className="text-sm text-gray-600">de 100 pontos</p>
                <Progress value={mockConsumerData.sustainabilityScore} className="h-3" />
                <Badge className="bg-green-100 text-green-800">
                  Eco Expert
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Environmental Impact */}
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <Leaf className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <p className="text-2xl text-gray-900">{mockConsumerData.wasteReduced} kg</p>
                <p className="text-xs text-gray-600">desperdício evitado</p>
                <Badge className="mt-2 bg-green-100 text-green-800">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +{mockConsumerData.wasteReductionTrend}%
                </Badge>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <TreePine className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <p className="text-2xl text-gray-900">{mockConsumerData.co2Saved} kg</p>
                <p className="text-xs text-gray-600">CO₂ poupados</p>
                <Badge className="mt-2 bg-blue-100 text-blue-800">
                  = {mockConsumerData.treesEquivalent} árvores
                </Badge>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Impact */}
          <Card>
            <CardHeader>
              <CardTitle>Impacto Detalhado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <Droplets className="w-6 h-6 text-blue-500 mx-auto mb-1" />
                  <p className="text-lg text-blue-600">{mockConsumerData.waterSaved}L</p>
                  <p className="text-xs text-gray-600">água poupada</p>
                </div>
                <div>
                  <Target className="w-6 h-6 text-green-500 mx-auto mb-1" />
                  <p className="text-lg text-green-600">R$ {mockConsumerData.moneySaved.toFixed(2)}</p>
                  <p className="text-xs text-gray-600">economizados</p>
                </div>
                <div>
                  <Clock className="w-6 h-6 text-purple-500 mx-auto mb-1" />
                  <p className="text-lg text-purple-600">{mockConsumerData.freshnessDays}</p>
                  <p className="text-xs text-gray-600">dias médios de frescor</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Progress Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Evolução Mensal</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600 mb-2">CO₂ Poupado (kg)</p>
                  <div className="h-20 flex items-end justify-between gap-2">
                    {mockConsumerData.monthlyProgress.map((point, index) => (
                      <div key={index} className="flex flex-col items-center flex-1">
                        <div 
                          className="bg-green-500 w-full rounded-t"
                          style={{ height: `${(point.co2 / 8) * 100}%` }}
                        />
                        <p className="text-xs text-gray-600 mt-1">{point.month}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="goals" className="space-y-4">
          {/* Weekly Goals */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-600" />
                Metas da Semana
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(mockConsumerData.weeklyGoals).map(([key, goal]) => {
                const progress = (goal.current / goal.target) * 100;
                const titles = {
                  wasteReduction: 'Redução de Desperdício',
                  co2Savings: 'CO₂ Poupado',
                  donations: 'Doações'
                };
                
                return (
                  <div key={key} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{titles[key as keyof typeof titles]}</span>
                      <span>{goal.current} / {goal.target} {goal.unit}</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                    <p className="text-xs text-gray-500">
                      {progress >= 100 ? '🎉 Meta alcançada!' : `${Math.round(progress)}% concluído`}
                    </p>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-yellow-600" />
                Conquistas Recentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {mockConsumerData.achievements.slice(0, 3).map((achievement, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                    <span className="text-2xl">{achievement.icon}</span>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">{achievement.title}</p>
                      <p className="text-xs text-gray-600">{achievement.description}</p>
                      <p className="text-xs text-gray-500">{achievement.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="community" className="space-y-4">
          {/* Community Impact */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                Impacto Comunitário
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <Heart className="w-8 h-8 text-red-500 mx-auto mb-2" />
                  <p className="text-2xl text-gray-900">{mockConsumerData.donationCount}</p>
                  <p className="text-xs text-gray-600">doações realizadas</p>
                </div>
                <div>
                  <Users className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <p className="text-2xl text-gray-900">{mockConsumerData.familiesHelped}</p>
                  <p className="text-xs text-gray-600">famílias ajudadas</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Community Ranking */}
          <Card>
            <CardHeader>
              <CardTitle>Ranking da Comunidade</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-2 bg-yellow-100 rounded">
                  <span className="text-sm">🥇 Você está em 3º lugar!</span>
                  <Badge className="bg-yellow-200 text-yellow-800">Top 5%</Badge>
                </div>
                <div className="text-center space-y-2">
                  <p className="text-sm text-gray-600">Pontuação total</p>
                  <p className="text-2xl text-purple-600">2,347</p>
                  <p className="text-xs text-gray-500">entre 1,234 usuários ativos</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Button
            onClick={() => onNavigate('community')}
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            <Heart className="w-4 h-4 mr-2" />
            Ver Oportunidades de Doação
          </Button>
        </TabsContent>
      </Tabs>
    </div>
  );

  const B2BAnalytics = () => (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="ai">IA & Predição</TabsTrigger>
          <TabsTrigger value="sustainability">Sustentabilidade</TabsTrigger>
          <TabsTrigger value="compliance">Conformidade</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Key Metrics */}
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <Package className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <p className="text-2xl text-gray-900">{mockB2BData.totalBatches}</p>
                <p className="text-xs text-gray-600">lotes processados</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 text-center">
                <Target className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <p className="text-2xl text-gray-900">{mockB2BData.qualityScore}%</p>
                <p className="text-xs text-gray-600">índice de qualidade</p>
              </CardContent>
            </Card>
          </div>

          {/* Loss Analysis */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-red-600" />
                Análise de Perdas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-3xl text-red-600">{mockB2BData.lossPercentage}%</p>
                <p className="text-sm text-gray-600">perdas no período</p>
                <Badge className="mt-2 bg-green-100 text-green-800">
                  <TrendingDown className="w-3 h-3 mr-1" />
                  {Math.abs(mockB2BData.lossReduction)}% redução
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Indicadores de Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Thermometer className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">Temp. Média</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm">{mockB2BData.avgTemperature}°C</p>
                    <p className="text-xs text-gray-500">Dentro do ideal</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Entregas no Prazo</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm">{mockB2BData.deliveryOnTime}%</p>
                    <p className="text-xs text-gray-500">Excelente</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-4">
          {/* AI Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-purple-600" />
                Performance da IA
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <p className="text-2xl text-purple-600">{mockB2BData.aiAccuracy}%</p>
                  <p className="text-xs text-gray-600">precisão das predições</p>
                </div>
                <div>
                  <p className="text-2xl text-blue-600">{mockB2BData.predictiveAlerts}</p>
                  <p className="text-xs text-gray-600">alertas preditivos</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Insights Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Evolução da IA</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-32 flex items-end justify-between gap-2">
                {mockB2BData.monthlyLosses.map((point, index) => (
                  <div key={index} className="flex flex-col items-center flex-1">
                    <div 
                      className="bg-purple-500 w-full rounded-t"
                      style={{ height: `${(point.ai / 100) * 100}%` }}
                    />
                    <p className="text-xs text-gray-600 mt-2">{point.month}</p>
                  </div>
                ))}
              </div>
              <p className="text-xs text-gray-500 text-center mt-2">
                Precisão da IA melhorando consistentemente
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sustainability" className="space-y-4">
          {/* Carbon Footprint */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TreePine className="w-5 h-5 text-green-600" />
                Pegada de Carbono
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-2">
                <p className="text-3xl text-green-600">{mockB2BData.carbonFootprint} kg</p>
                <p className="text-sm text-gray-600">CO₂ equivalente este mês</p>
                <Badge className="bg-green-100 text-green-800">
                  <TrendingDown className="w-3 h-3 mr-1" />
                  {Math.abs(mockB2BData.carbonReduction)}% redução
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Sustainability Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Métricas de Sustentabilidade</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(mockB2BData.sustainabilityMetrics).map(([key, value]) => {
                const titles = {
                  energyEfficiency: 'Eficiência Energética',
                  wasteReduction: 'Redução de Resíduos',
                  carbonNeutral: 'Neutralidade de Carbono',
                  circularEconomy: 'Economia Circular'
                };
                
                return (
                  <div key={key} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{titles[key as keyof typeof titles]}</span>
                      <span>{value}%</span>
                    </div>
                    <Progress value={value} className="h-2" />
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="compliance" className="space-y-4">
          {/* Compliance Score */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Conformidade Regulatória
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center space-y-3">
                <p className="text-4xl text-blue-600">{mockB2BData.complianceScore}%</p>
                <p className="text-sm text-gray-600">índice de conformidade</p>
                <Progress value={mockB2BData.complianceScore} className="h-3" />
                <Badge className="bg-blue-100 text-blue-800">
                  Excelente Conformidade
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Blockchain Records */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-600" />
                Registros Blockchain
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-2xl text-yellow-600">{mockB2BData.blockchainRecords.toLocaleString()}</p>
                <p className="text-sm text-gray-600">registros imutáveis</p>
                <p className="text-xs text-gray-500 mt-2">
                  100% dos dados verificados e protegidos
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Alerts Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Resumo de Alertas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {mockB2BData.alerts.map((alert, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm">{alert.description}</span>
                    <Badge variant={alert.type === 'critical' ? 'destructive' : alert.type === 'warning' ? 'secondary' : 'default'}>
                      {alert.count}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onNavigate('dashboard')}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <h1 className="text-xl">
          {userType === 'consumer' ? 'Meu Impacto Ambiental' : 'Análises Avançadas'}
        </h1>
      </div>

      {userType === 'consumer' ? <ConsumerAnalytics /> : <B2BAnalytics />}
    </div>
  );
}