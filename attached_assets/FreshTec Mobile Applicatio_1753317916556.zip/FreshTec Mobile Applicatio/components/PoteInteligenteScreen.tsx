import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { 
  ArrowLeft, 
  Plus, 
  Package, 
  Thermometer, 
  Calendar,
  AlertTriangle,
  CheckCircle,
  Bluetooth,
  QrCode
} from 'lucide-react';
import type { Screen } from '../App';

interface PoteInteligenteScreenProps {
  onNavigate: (screen: Screen) => void;
}

export function PoteInteligenteScreen({ onNavigate }: PoteInteligenteScreenProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newPoteName, setNewPoteName] = useState('');

  const mockPotes = [
    {
      id: 'pote-001',
      name: 'Geladeira Principal',
      isConnected: true,
      temperature: '3°C',
      items: [
        { name: 'Tomates', freshness: 'green', daysLeft: 3 },
        { name: 'Alface', freshness: 'yellow', daysLeft: 1 },
        { name: 'Cenouras', freshness: 'green', daysLeft: 5 }
      ]
    },
    {
      id: 'pote-002',
      name: 'Fruteira Smart',
      isConnected: true,
      temperature: '18°C',
      items: [
        { name: 'Bananas', freshness: 'red', daysLeft: 0 },
        { name: 'Maçãs', freshness: 'green', daysLeft: 7 }
      ]
    },
    {
      id: 'pote-003',
      name: 'Pote Pequeno',
      isConnected: false,
      temperature: '--',
      items: []
    }
  ];

  const getFreshnessColor = (freshness: string) => {
    switch (freshness) {
      case 'green': return 'bg-green-500';
      case 'yellow': return 'bg-yellow-500';
      case 'red': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const handleAddPote = () => {
    console.log('Adicionando novo pote:', newPoteName);
    setNewPoteName('');
    setIsAddDialogOpen(false);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('dashboard')}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-xl">Potes Inteligentes</h1>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-green-600 hover:bg-green-700">
              <Plus className="w-4 h-4 mr-2" />
              Adicionar
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Conectar Novo Pote</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="name">Nome do Pote</Label>
                <Input
                  id="name"
                  placeholder="Ex: Geladeira da Cozinha"
                  value={newPoteName}
                  onChange={(e) => setNewPoteName(e.target.value)}
                />
              </div>
              
              <div className="space-y-3">
                <p className="text-sm text-gray-600">Método de conexão:</p>
                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" className="h-20 flex-col">
                    <Bluetooth className="w-6 h-6 mb-2 text-blue-600" />
                    <span className="text-sm">Bluetooth</span>
                  </Button>
                  <Button variant="outline" className="h-20 flex-col">
                    <QrCode className="w-6 h-6 mb-2 text-green-600" />
                    <span className="text-sm">QR Code</span>
                  </Button>
                </div>
              </div>
              
              <Button onClick={handleAddPote} className="w-full bg-green-600 hover:bg-green-700">
                Conectar Pote
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="p-4 text-center">
            <Package className="w-6 h-6 text-green-600 mx-auto mb-2" />
            <p className="text-xl text-gray-900">{mockPotes.filter(p => p.isConnected).length}</p>
            <p className="text-xs text-gray-600">Conectados</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <CheckCircle className="w-6 h-6 text-blue-600 mx-auto mb-2" />
            <p className="text-xl text-gray-900">
              {mockPotes.reduce((acc, pote) => acc + pote.items.filter(item => item.freshness === 'green').length, 0)}
            </p>
            <p className="text-xs text-gray-600">Frescos</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <AlertTriangle className="w-6 h-6 text-red-600 mx-auto mb-2" />
            <p className="text-xl text-gray-900">
              {mockPotes.reduce((acc, pote) => acc + pote.items.filter(item => item.freshness === 'red').length, 0)}
            </p>
            <p className="text-xs text-gray-600">Críticos</p>
          </CardContent>
        </Card>
      </div>

      {/* Potes List */}
      <div className="space-y-4">
        {mockPotes.map((pote) => (
          <Card key={pote.id} className={`${!pote.isConnected ? 'opacity-60' : ''}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Package className="w-5 h-5 text-gray-600" />
                  {pote.name}
                </CardTitle>
                <div className="flex items-center gap-2">
                  {pote.isConnected && (
                    <div className="flex items-center gap-1">
                      <Thermometer className="w-3 h-3 text-blue-500" />
                      <span className="text-xs">{pote.temperature}</span>
                    </div>
                  )}
                  <Badge 
                    className={pote.isConnected ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}
                  >
                    {pote.isConnected ? 'Conectado' : 'Desconectado'}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            
            {pote.isConnected && pote.items.length > 0 && (
              <CardContent>
                <div className="space-y-2">
                  {pote.items.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${getFreshnessColor(item.freshness)}`} />
                        <span className="text-sm">{item.name}</span>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-gray-600">
                          {item.daysLeft > 0 ? `${item.daysLeft} dias` : 'Hoje'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                
                {pote.items.some(item => item.freshness === 'red') && (
                  <div className="mt-3 p-2 bg-red-50 rounded border border-red-200">
                    <div className="flex items-center gap-2 text-red-800">
                      <AlertTriangle className="w-4 h-4" />
                      <p className="text-sm">Itens próximos do vencimento!</p>
                    </div>
                  </div>
                )}
              </CardContent>
            )}
            
            {pote.isConnected && pote.items.length === 0 && (
              <CardContent>
                <p className="text-sm text-gray-500 text-center py-4">
                  Nenhum item monitorado
                </p>
              </CardContent>
            )}
            
            {!pote.isConnected && (
              <CardContent>
                <Button variant="outline" className="w-full">
                  <Bluetooth className="w-4 h-4 mr-2" />
                  Reconectar
                </Button>
              </CardContent>
            )}
          </Card>
        ))}
      </div>

      {/* Help Section */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Package className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <p className="text-sm text-blue-800 mb-1">Dica do FreshTec</p>
              <p className="text-xs text-blue-700">
                Mantenha seus potes inteligentes sempre conectados para monitoramento em tempo real. 
                Use o scanner QR para adicionar novos alimentos rapidamente.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}