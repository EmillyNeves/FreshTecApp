import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  ArrowLeft, 
  Users, 
  MapPin, 
  Heart, 
  Clock, 
  Search,
  Navigation as NavigationIcon,
  Gift,
  Star,
  Phone,
  Calendar
} from 'lucide-react';
import type { Screen } from '../App';

interface CommunityScreenProps {
  onNavigate: (screen: Screen) => void;
}

export function CommunityScreen({ onNavigate }: CommunityScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTab, setSelectedTab] = useState('donate');

  const mockDonationItems = [
    {
      id: '1',
      name: 'Bananas Nanica',
      quantity: '2 kg',
      expiresIn: '6 horas',
      freshness: 'yellow',
      description: 'Bananas maduras, ótimas para vitaminas'
    },
    {
      id: '2',
      name: 'Pães Integrais',
      quantity: '8 unidades',
      expiresIn: '1 dia',
      freshness: 'green',
      description: 'Pães frescos do dia'
    },
    {
      id: '3',
      name: 'Iogurte Natural',
      quantity: '6 potes',
      expiresIn: '3 dias',
      freshness: 'green',
      description: 'Iogurte natural, sem conservantes'
    }
  ];

  const mockDonationPoints = [
    {
      id: '1',
      name: 'Casa de Apoio São Francisco',
      address: 'Rua das Flores, 123 - Centro',
      distance: '0.8 km',
      rating: 4.8,
      phone: '(11) 3456-7890',
      hours: '08:00 - 18:00',
      acceptsTypes: ['Frutas', 'Verduras', 'Pães', 'Laticínios'],
      urgent: false
    },
    {
      id: '2',
      name: 'ONG Alimentar+',
      address: 'Av. Principal, 456 - Vila Nova',
      distance: '1.2 km',
      rating: 4.9,
      phone: '(11) 2345-6789',
      hours: '07:00 - 19:00',
      acceptsTypes: ['Todos os tipos'],
      urgent: true
    },
    {
      id: '3',
      name: 'Banco de Alimentos Municipal',
      address: 'Rua Central, 789 - Downtown',
      distance: '2.1 km',
      rating: 4.7,
      phone: '(11) 1234-5678',
      hours: '09:00 - 17:00',
      acceptsTypes: ['Não perecíveis', 'Frutas', 'Verduras'],
      urgent: false
    }
  ];

  const mockCommunityStats = {
    totalDonations: 127,
    foodSaved: 89.3,
    familiesHelped: 234,
    co2Saved: 156.7
  };

  const getFreshnessColor = (freshness: string) => {
    switch (freshness) {
      case 'green': return 'bg-green-500';
      case 'yellow': return 'bg-yellow-500';
      case 'red': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const DonateTab = () => (
    <div className="space-y-4">
      <div className="text-center space-y-2">
        <Gift className="w-12 h-12 text-green-600 mx-auto" />
        <p className="text-lg text-gray-900">Doe seus alimentos</p>
        <p className="text-sm text-gray-600">
          Ajude a reduzir o desperdício e alimente quem precisa
        </p>
      </div>

      {mockDonationItems.length > 0 ? (
        <div className="space-y-3">
          <h4 className="text-gray-900">Seus itens próximos do vencimento</h4>
          {mockDonationItems.map((item) => (
            <Card key={item.id} className="border-orange-200 bg-orange-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${getFreshnessColor(item.freshness)}`} />
                    <span className="text-gray-900">{item.name}</span>
                  </div>
                  <Badge variant="outline" className="text-orange-700 border-orange-300">
                    <Clock className="w-3 h-3 mr-1" />
                    {item.expiresIn}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                <p className="text-sm text-gray-700 mb-3">Quantidade: {item.quantity}</p>
                <Button className="w-full bg-green-600 hover:bg-green-700" size="sm">
                  <Heart className="w-4 h-4 mr-2" />
                  Doar Agora
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="p-6 text-center">
            <Heart className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-600">Nenhum item para doação no momento</p>
            <p className="text-sm text-gray-500">Continue monitorando seus alimentos!</p>
          </CardContent>
        </Card>
      )}
    </div>
  );

  const LocationsTab = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Search className="w-4 h-4 text-gray-500" />
        <Input
          placeholder="Buscar pontos de doação..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1"
        />
      </div>

      <div className="space-y-3">
        {mockDonationPoints
          .filter(point => 
            point.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            point.address.toLowerCase().includes(searchQuery.toLowerCase())
          )
          .map((point) => (
            <Card key={point.id} className={point.urgent ? 'border-red-200 bg-red-50' : ''}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-gray-900">{point.name}</h4>
                      {point.urgent && (
                        <Badge className="bg-red-100 text-red-800">
                          Urgente
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-sm text-gray-600 mb-1">
                      <Star className="w-3 h-3 text-yellow-500" />
                      <span>{point.rating}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline" className="text-blue-700 border-blue-300">
                      <MapPin className="w-3 h-3 mr-1" />
                      {point.distance}
                    </Badge>
                  </div>
                </div>

                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-start gap-2">
                    <MapPin className="w-3 h-3 mt-0.5 text-gray-500" />
                    <span>{point.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3 h-3 text-gray-500" />
                    <span>{point.hours}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-3 h-3 text-gray-500" />
                    <span>{point.phone}</span>
                  </div>
                </div>

                <div className="mt-3">
                  <p className="text-xs text-gray-500 mb-1">Aceita:</p>
                  <div className="flex flex-wrap gap-1">
                    {point.acceptsTypes.map((type, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {type}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2 mt-3">
                  <Button variant="outline" size="sm" className="flex-1">
                    <NavigationIcon className="w-3 h-3 mr-1" />
                    Rota
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Calendar className="w-3 h-3 mr-1" />
                    Agendar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
      </div>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <p className="text-sm text-blue-800 mb-1">Dica do FreshTec</p>
              <p className="text-xs text-blue-700">
                Entre em contato antes de ir para confirmar se estão aceitando doações. 
                Alguns pontos têm horários específicos para recebimento.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-6">
      <div className="flex items-center gap-3 mb-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onNavigate('dashboard')}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-xl">Compartilhamento Comunitário</h1>
          <p className="text-sm text-gray-600">Juntos contra o desperdício</p>
        </div>
      </div>

      {/* Community Impact Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-green-600" />
            Impacto da Comunidade
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <p className="text-2xl text-green-600">{mockCommunityStats.totalDonations}</p>
              <p className="text-xs text-gray-600">doações realizadas</p>
            </div>
            <div className="text-center">
              <p className="text-2xl text-blue-600">{mockCommunityStats.foodSaved} kg</p>
              <p className="text-xs text-gray-600">alimentos salvos</p>
            </div>
            <div className="text-center">
              <p className="text-2xl text-purple-600">{mockCommunityStats.familiesHelped}</p>
              <p className="text-xs text-gray-600">famílias ajudadas</p>
            </div>
            <div className="text-center">
              <p className="text-2xl text-orange-600">{mockCommunityStats.co2Saved} kg</p>
              <p className="text-xs text-gray-600">CO₂ poupados</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="donate">Doar</TabsTrigger>
          <TabsTrigger value="locations">Pontos de Doação</TabsTrigger>
        </TabsList>
        
        <TabsContent value="donate" className="mt-4">
          <DonateTab />
        </TabsContent>
        
        <TabsContent value="locations" className="mt-4">
          <LocationsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}