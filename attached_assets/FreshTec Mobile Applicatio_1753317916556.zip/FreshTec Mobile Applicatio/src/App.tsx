import React, { useState } from 'react';
import { LoginScreen } from '../components/LoginScreen';
import { Dashboard } from '../components/Dashboard';
import { QRScanner } from '../components/QRScanner';
import { BatchDetails } from '../components/BatchDetails';
import { PoteInteligenteScreen } from '../components/PoteInteligenteScreen';
import { AnalyticsScreen } from '../components/AnalyticsScreen';
import { SettingsScreen } from '../components/SettingsScreen';
import { CommunityScreen } from '../components/CommunityScreen';
import { Navigation } from '../components/Navigation';

export type UserType = 'producer' | 'transporter' | 'retailer' | 'consumer';
export type Screen = 'login' | 'dashboard' | 'scanner' | 'batch' | 'pote' | 'analytics' | 'settings' | 'community';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [userType, setUserType] = useState<UserType>('consumer');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [selectedBatchId, setSelectedBatchId] = useState<string>('');

  const handleLogin = (type: UserType) => {
    setUserType(type);
    setIsAuthenticated(true);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUserType('consumer');
    setCurrentScreen('login');
  };

  const handleBatchSelect = (batchId: string) => {
    setSelectedBatchId(batchId);
    setCurrentScreen('batch');
  };

  const handleNavigate = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const renderScreen = () => {
    if (!isAuthenticated) {
      return <LoginScreen onLogin={handleLogin} />;
    }
    switch (currentScreen) {
      case 'dashboard':
        return (
          <Dashboard 
            userType={userType} 
            onBatchSelect={handleBatchSelect}
            onNavigate={handleNavigate}
          />
        );
      case 'scanner':
        return <QRScanner onNavigate={handleNavigate} />;
      case 'batch':
        return (
          <BatchDetails 
            batchId={selectedBatchId} 
            userType={userType}
            onNavigate={handleNavigate}
          />
        );
      case 'pote':
        return <PoteInteligenteScreen onNavigate={handleNavigate} />;
      case 'analytics':
        return <AnalyticsScreen userType={userType} onNavigate={handleNavigate} />;
      case 'settings':
        return <SettingsScreen onLogout={handleLogout} onNavigate={handleNavigate} />;
      case 'community':
        return <CommunityScreen onNavigate={handleNavigate} />;
      default:
        return (
          <Dashboard 
            userType={userType} 
            onBatchSelect={handleBatchSelect}
            onNavigate={handleNavigate}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto relative">
      <div className="flex-1 overflow-hidden">
        {renderScreen()}
      </div>
      {isAuthenticated && (
        <Navigation 
          currentScreen={currentScreen} 
          onNavigate={handleNavigate}
          userType={userType}
        />
      )}
    </div>
  );
}