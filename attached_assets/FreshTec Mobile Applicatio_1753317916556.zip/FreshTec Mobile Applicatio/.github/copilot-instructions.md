# Copilot Instructions for FreshTec Mobile Application

## Project Overview
- This is a React (TypeScript/JavaScript) web application structured for mobile-like usage.
- Main entry point: `src/index.js` renders the root `App` component from `App.tsx`.
- All screens and UI logic are managed via React components in `components/`.
- Navigation between screens is handled by state in `App.tsx` (see `currentScreen`, `userType`, etc.).

## Key Directories & Files
- `App.tsx`: Central app logic, screen routing, authentication state.
- `components/`: Contains all major screens and UI elements. Subfolders like `ui/` hold reusable UI primitives.
- `public/index.html`: Required HTML entry point with `<div id="root"></div>`.
- `src/index.js`: ReactDOM entry, must import `App` from correct path.
- `styles/globals.css`: Global CSS styles.

## Build & Run
- Use `npm install` to install dependencies.
- Use `npm start` to run the development server (requires `react-scripts`).
- If missing scripts or dependencies, update `package.json` accordingly.

## Patterns & Conventions
- Screen navigation is managed by state in `App.tsx` (not by React Router).
- Props are used for communication between parent and child components (e.g., `onLogin`, `onBatchSelect`).
- TypeScript types for user roles and screens are defined in `App.tsx` and passed as props.
- UI primitives in `components/ui/` are imported and composed in screens.
- No backend/API integration is present in the visible codebase; all logic is client-side.

## Troubleshooting
- If you see errors about missing files (`index.html`, `index.js`), create them with minimal required content.
- If `react-scripts` is missing, add it to `dependencies` and reinstall.
- For new screens, add a component in `components/` and update the switch logic in `App.tsx`.

## Example: Adding a New Screen
1. Create `components/NewScreen.tsx`.
2. Add `'newscreen'` to the `Screen` type in `App.tsx`.
3. Update the switch in `renderScreen()` to handle `'newscreen'`.
4. Pass any required props from `App.tsx`.

## External Dependencies
- Uses React 19.x, ReactDOM, and `react-scripts` for build/run.
- TypeScript types are present but not enforced everywhere; check imports and props for type consistency.

---
For questions about unclear patterns or missing documentation, ask the user for clarification or examples from their workflow.
import App from './App';